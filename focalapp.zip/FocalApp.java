import com.drew.imaging.ImageMetadataReader;
import com.drew.imaging.ImageProcessingException;
import com.drew.metadata.exif.ExifReader;
import com.drew.metadata.iptc.IptcReader;
import com.sun.image.codec.jpeg.JPEGCodec;
import com.sun.image.codec.jpeg.JPEGDecodeParam;
import com.sun.image.codec.jpeg.JPEGImageDecoder;
import com.drew.metadata.*;
import com.drew.metadata.exif.ExifDirectory;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.FilenameFilter;
import java.util.*;
import java.util.regex.*;


public class FocalApp {
  public FocalApp(String dirname) {
    // list of files
    File folder = new File(dirname);
    List<File> filelist = new ArrayList<File>();
    this.getFiles(folder, filelist);

    // key - value pairs: focallength - count
    SortedMap<Double, Integer> focalmap = new TreeMap<Double,Integer>();

    // for all found files
    for (Iterator it=filelist.iterator(); it.hasNext(); ) {
      String filename = it.next().toString();
      //System.out.println(" --- working on file: "+filename);

      File imageFile = new File(filename);
      try {
        Metadata metadata = ImageMetadataReader.readMetadata(imageFile);
        Directory exifDirectory = metadata.getDirectory(ExifDirectory.class);

        Double cameraFocus = 0.0;
        try {
          String cameraFocusString = exifDirectory.getString(ExifDirectory.TAG_FOCAL_LENGTH);
          if (cameraFocusString != null) {
            // value is present
            cameraFocus = Double.parseDouble(cameraFocusString);
          }
          //System.out.println("Focus lenght = " + cameraFocus);
        } catch(NumberFormatException nFE) {
          //System.out.println("Not an Integer");
        }

        Integer currentimagecount = 0;
        if(focalmap.containsKey(cameraFocus)) {
          //System.out.println("key already tgere");
          currentimagecount = focalmap.get(cameraFocus);
        }
        currentimagecount++;
        //System.out.println("putting in map: "+currentvalue);
        focalmap.put(cameraFocus, currentimagecount);
      } catch (ImageProcessingException e) {
        System.err.println("skipping file "+filename+"due to error:"+e);
      }
    }

    Integer totalimagecount = 0;


    TreeSet set = new TreeSet(new Comparator() {
      public int compare(Object obj, Object obj1) {
        int vcomp = ((Comparable) ((Map.Entry) obj1).getValue()).compareTo(((Map.Entry)
        obj).getValue());
        if (vcomp != 0) return vcomp;
        else return ((Comparable) ((Map.Entry) obj1).getKey()).compareTo(((Map.Entry)
        obj).getKey());

      }
    });

    set.addAll(focalmap.entrySet());
    System.out.println("focal length in mm;number of images;");
    for (Iterator i = set.iterator(); i.hasNext();) {
      Map.Entry entry = (Map.Entry) i.next();
      Double key = (Double) entry.getKey();
      String keyname;
      if(key == 0) {
        keyname = "?";
      } else {
        keyname = key.toString();
      }
      Integer numimages = (Integer) entry.getValue();
      System.out.println(keyname + ";" + numimages+";");
      totalimagecount+=numimages;
    }

    //System.out.println("total: "+totalimagecount+" images.");
  }

  private void getFiles(File folder, List<File> list) {
    folder.setReadOnly();

    File[] files = folder.listFiles(new ImageFileFilter());
    for(int j = 0; j < files.length; j++) {
      list.add(files[j]);
    }

    File[] subfolders = folder.listFiles();
    for(int j = 0; j < subfolders.length; j++) {
      if(subfolders[j].isDirectory()) {
        getFiles(subfolders[j], list);
      }
    }
  }

  public static void main(String[] args)
  {
    if(args.length > 0 && args[0].length() > 0) {
      String imagepath = args[0];
      if(new File(imagepath).exists()) {
        new FocalApp(imagepath);
      } else {
        System.err.println("given image directory not found!");
        System.exit(2);
      }
    } else {
      System.err.println("please give a directory containing the images!");
      System.exit(1);
    }
  }
}

class ImageFileFilter implements FilenameFilter
{
  public boolean accept( File f, String s )
  {
    Pattern pattern = Pattern.compile("([^\\s]+(?=\\.(jpg|crw|cr2|nef|arw|tiff|tif))\\.\\2)", Pattern.CASE_INSENSITIVE);
    return pattern.matcher(s).matches();
  }
}





// mDCM: A C# DICOM library
//
// Copyright (c) 2006-2008  Colby Dillion
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
// Author:
//    Colby Dillion (colby.dillion@gmail.com)

using System;
using System.Collections.Generic;
using System.Text;

namespace Dicom.Data {
	public enum DicomFieldDefault {
		None,
		Null,
		Default,
		MinValue,
		MaxValue,
		DateTimeNow,
		StringEmpty,
		DBNull,
		EmptyArray
	}

	[AttributeUsage(AttributeTargets.Field | AttributeTargets.Property)]
	public sealed class DicomFieldAttribute : Attribute {
		private DcmTag _tag;
		private DicomFieldDefault _default;
		private bool _defltOnZL;
		private bool _createEmpty;

		public DicomFieldAttribute(uint tag) {
			_tag = new DcmTag(tag);
			_default = DicomFieldDefault.None;
			_defltOnZL = false;
			_createEmpty = false;
		}

		public DicomFieldAttribute(ushort group, ushort element) {
			_tag = new DcmTag(group, element);
			_default = DicomFieldDefault.None;
			_defltOnZL = false;
			_createEmpty = false;
		}

		public DcmTag Tag {
			get { return _tag; }
		}

		public DicomFieldDefault DefaultValue {
			get { return _default; }
			set { _default = value; }
		}

		public bool UseDefaultForZeroLength {
			get { return _defltOnZL; }
			set { _defltOnZL = value; }
		}

		public bool CreateEmptyElement {
			get { return _createEmpty; }
			set { _createEmpty = value; }
		}
	}

	[AttributeUsage(AttributeTargets.Class)]
	public sealed class DicomClassAttribute : Attribute {
		private bool _defltOnZL;
		private bool _createEmpty;

		public DicomClassAttribute() {
		}

		public bool UseDefaultForZeroLength {
			get { return _defltOnZL; }
			set { _defltOnZL = value; }
		}

		public bool CreateEmptyElement {
			get { return _createEmpty; }
			set { _createEmpty = value; }
		}
	}
}

﻿#region information
/// 2009/01/23
/// Sebastian Lange
#endregion

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;
using System.Text;
using System.Windows.Forms;

using Dicom.Wrapper;

namespace Dicom.Forms
{
    /// <summary>
    /// NET C# Form Class with UI for viewing dicom file's image data and
    /// patient dateset meta information.
    /// </summary>
    public partial class zDicomViewerForm : Form
    {
        /// <summary>
        /// CTOR. Creates DicomUtil object.
        /// </summary>
        public zDicomViewerForm()
        {
            InitializeComponent();
            // init dicom util
        }

        /// <summary>
        /// Quits the application.
        /// </summary>
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        /// <summary>
        /// Displays open dicom file dialog. Passes chosen filename to Dicom Util object.
        /// The forms paintbox is filled with the scaled image from the dicom file and the
        /// metadata is passed to the textboxes.
        /// </summary>
        private void openFileToolStripMenuItem_Click(object sender, EventArgs e)
        {            
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Multiselect = false;
            ofd.Filter = "dicom files (*.dcm)|*.dcm|All files (*.*)|*.*";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                ClearResources();
                m_dcw = WrapperBase.CreateDicomWrapper(ofd.FileName);
                if (m_dcw == null)
                {
                    MessageBox.Show("Unsupported DICOM format.", "Error opening dicom file", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                
                // get image
                Image img = m_dcw.DicomImage;
                if (img == null)
                {
                    MessageBox.Show(m_dcw.GetLastError() + "\nImage data will be ignored.", "Error reading image data", MessageBoxButtons.OK, MessageBoxIcon.Error);                    
                }
                else
                    picBox.Image = ScaleToFixedSize(img, picBox.Width, picBox.Height, this.BackColor);

                // get metadata
                string pat_name = m_dcw.PatientName;
                if(pat_name != null)
                    tbxPatientName.Text = pat_name;

                string pat_birthdate = m_dcw.PatientBirthdate;
                if(pat_birthdate != null)
                    tbxPatientBirthdate.Text = pat_birthdate;

                string pat_id = m_dcw.PatientID;
                if(pat_id != null)
                    tbxPatientID.Text = pat_id;
            }
        }

        /// <summary>
        /// Saves shown image from the dicom file as jpeg file.
        /// </summary>
        private void saveImageToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // use unscaled original file to save
            Image img = m_dcw.DicomImage;
            if (img == null)
            {
                MessageBox.Show("Please load a dicom file first!", "Error saving image", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "jpeg image (*.jpg)|*.jpg";
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                img.Save(sfd.FileName, ImageFormat.Jpeg);
            }
        }

        /// <summary>
        /// Resets resources and calls garbage collection.
        /// </summary>
        private void ClearResources()
        {
            picBox.Image = null;
            m_dcw = null;
            // trashcan
            GC.Collect();
            GC.WaitForPendingFinalizers();
            GC.Collect();
        }

        /// <summary>
        /// Utility method. Scales given image to given sizes using high quality bicubic interpolation
        /// </summary>
        /// <param name="imgPhoto">Input image</param>
        /// <param name="Width">Target width</param>
        /// <param name="Height">Target height</param>
        /// <param name="clearcolor">Clear color for the background canvas</param>
        /// <returns>Rescaled Image</returns>
        private static Image ScaleToFixedSize(Image imgPhoto, int Width, int Height, Color clearcolor)
        {
            int sourceWidth = imgPhoto.Width;
            int sourceHeight = imgPhoto.Height;
            int sourceX = 0;
            int sourceY = 0;
            int destX = 0;
            int destY = 0;

            float nPercent = 0;
            float nPercentW = 0;
            float nPercentH = 0;

            nPercentW = ((float)Width / (float)sourceWidth);
            nPercentH = ((float)Height / (float)sourceHeight);
            if (nPercentH < nPercentW)
            {
                nPercent = nPercentH;
                destX = System.Convert.ToInt16((Width -
                              (sourceWidth * nPercent)) / 2);
            }
            else
            {
                nPercent = nPercentW;
                destY = System.Convert.ToInt16((Height -
                              (sourceHeight * nPercent)) / 2);
            }

            int destWidth = (int)(sourceWidth * nPercent);
            int destHeight = (int)(sourceHeight * nPercent);

            Bitmap bmPhoto = new Bitmap(Width, Height,
                              PixelFormat.Format24bppRgb);
            bmPhoto.SetResolution(imgPhoto.HorizontalResolution,
                             imgPhoto.VerticalResolution);

            Graphics grPhoto = Graphics.FromImage(bmPhoto);
            grPhoto.Clear(clearcolor);
            grPhoto.InterpolationMode =
                    InterpolationMode.HighQualityBicubic;

            grPhoto.DrawImage(imgPhoto,
                new Rectangle(destX, destY, destWidth, destHeight),
                new Rectangle(sourceX, sourceY, sourceWidth, sourceHeight),
                GraphicsUnit.Pixel);

            grPhoto.Dispose();
            return bmPhoto;
        }

        //Members
        /// Instance of the dicom wrapper
        private WrapperBase m_dcw = null;
    }
}

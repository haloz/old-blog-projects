﻿#region information
/// 2009/01/23
/// Sebastian Lange
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

using Dicom.Data;


namespace Dicom.Wrapper
{
    /// <summary>
    /// Utility class, connects with mDCM-library. Has static method(s)
    /// for creating specific objects depending on dicom file/image format.
    /// Supplies methods to fetch image and meta data via connected dicom
    /// mDCM-library.
    /// </summary>
    public class Utility
    {
        /// <summary>
        /// CTOR. Auto-Loads dicom dictionaries.
        /// </summary>
        public Utility()            
        {
            m_lasterror = String.Empty;
            LoadDictionaries();
        }

        /// <summary>
        /// Loads dictionary files if present.
        /// </summary>
        private void LoadDictionaries()
        {
            if (File.Exists("dicom.dic"))
                DcmDictionary.ImportDictionary("dicom.dic");
            else
                DcmDictionary.LoadInternalDictionary();

            if (File.Exists("private.dic"))
                DcmDictionary.ImportDictionary("private.dic");
        }

        /// <summary>
        /// Opens the supplied dicom file.
        /// </summary>
        /// <param name="file">Full file path with filename</param>
        public bool SetFile(string file)
        {
            m_filename = file;			

			bool success = false;
			m_fileformat = new DicomFileFormat();                            
			try {
				//ClearDump();
				m_fileformat.Load(file, DicomReadOptions.Default |
					DicomReadOptions.KeepGroupLengths |
					DicomReadOptions.DeferLoadingLargeElements |
					DicomReadOptions.DeferLoadingPixelData);

				success = true;
			}
			catch (Exception e)
            {
                m_lasterror = "Error parsing file! : " + e.Message + "\n";
                return false;
			}

			return success;
		}

        /// <summary>
        /// Returns type information of the responsible child class, depending
        /// on the modality information within the dicom file.
        /// </summary>
        /// <returns>string of the modality type</returns>
        public string GetDicomType()
        {
            if (m_fileformat == null)
            {
                m_lasterror = "Please load a file first\n";
                return "";
            }
            string dicom_type = null;
            if (!GetMetaData(0x0008, 0x0060, out dicom_type))
            {
                m_lasterror = "Could not find modality information\n";
                return null;
            }
            return dicom_type;
        }

        /// <summary>
        /// Returns image data from the dicom file within the supplied Image parameter.
        /// </summary>
        /// <param name="img">out-parameter containing the image data from the dicom file.
        /// (currently only first image returned).
        /// </param>
        /// <returns>true if image was assigned successfully. false in case of an error,
        /// see GetLastError() for details.
        /// </returns>
        public bool GetDicomImage(out System.Drawing.Image img)
        {
            img = null;
            if (m_fileformat == null)
            {
                m_lasterror = "Please load a file first" + "\n";
                return false;
            }

	        DcmPixelData pixeldata = new DcmPixelData(m_fileformat.Dataset);

            if (pixeldata.NumberOfFrames == 0)
            {
                m_lasterror = "No image data found" + "\n";
                return false;
            }
            else if (pixeldata.NumberOfFrames == 1) // currently only first img 
            {
                MemoryStream strm = null;                    
                try
                {
                    strm = new MemoryStream(pixeldata.GetFrameDataU8(0)); //raw u8
                    img = System.Drawing.Image.FromStream(strm);
                }
                catch (Exception ex)
                {
                    m_lasterror = "Error reading image from dicom file (" + ex.ToString() + ")" + "\n";
                    return false;
                }
                return true;
            }
            m_lasterror = "Unknown error reading image data" + "\n";
            return false;
        }

        /// <summary>
        /// Returns the patient's name (3.1 "Patient’s Name" (0010,0010))
        /// </summary>
        /// <param name="patient_name">out string containing the name of the patient</param>
        /// <returns>true or false, whether metadata could be successfully read</returns>
        public bool GetPatientName(out string patient_name)
        {
            return GetMetaData(0x0010, 0x0010, out patient_name);
        }

        /// <summary>
        /// Returns the patient's birthdate as string (F.3.2 "Patient’s Birthdate" (0010,0030))
        /// </summary>
        /// <param name="patient_birthdate">out string containing the birthdate of the patient</param>
        /// <returns>true or false, whether metadata could be successfully read</returns>
        public bool GetPatientBirthdate(out string patient_birthdate)
        {
            return GetMetaData(0x0010, 0x0030, out patient_birthdate);
        }

        /// <summary>
        /// Returns the patient's ID as string (F.3.3 "Patient ID" (0010,0020).
        /// The ID may be non-numerical, i.e. "F1234567".
        /// </summary>
        /// <param name="patient_id">out string containing the ID of the patient</param>
        /// <returns>true or false, whether metadata could be successfully read</returns>
        public bool GetPatientID(out string  patient_id)
        {
            return GetMetaData(0x0010, 0x0020, out patient_id);
        }

        /// <summary>
        /// Reads data from the dicom file's dataset using the given tag parameters.
        /// </summary>
        /// <param name="tag1">numerical, group tag to address the dicom metadata element</param>
        /// <param name="tag2">numerical, element tag to address the dicom metadata element</param>
        /// <param name="data">out string containing the value data from the read element</param>
        /// <returns>true if the data could be successfully read</returns>
        private bool GetMetaData(ushort tag1, ushort tag2, out string data)
        {
            data = String.Empty;
            if (m_fileformat == null)
            {
                m_lasterror = "Please load a file first" + "\n";
                return false;
            }

            try
            {
                DcmTag dcmtag = new DcmTag(tag1, tag2);
                DcmElement dcmel = m_fileformat.Dataset.GetElement(dcmtag);
                data = dcmel.GetValueString();
            }
            catch (Exception ex)
            {
                m_lasterror = "Error reading meta data from dicom file's dataset (" + ex.ToString() + ")" + "\n";
                return false;
            }
            return true;
        }

        /// <summary>
        /// Returns a string of the last error occured.
        /// </summary>
        /// <returns>string with the error wording.</returns>
        public string GetLastError()
        {
            return m_lasterror;
        }

        // Members
        /// filename of the dicom file
        protected string m_filename = null; 
        /// string containing the last error msg
        protected string m_lasterror = null;
        /// opened dicom fileformat object
        protected DicomFileFormat m_fileformat = null; 
    }
}

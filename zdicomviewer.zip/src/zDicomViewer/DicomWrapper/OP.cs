﻿#region information
/// 2009/01/23
/// Sebastian Lange
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;

namespace Dicom.Wrapper
{
    /// <summary>
    /// Handles Ophthalmic Photography images.
    /// </summary>
    class OP : WrapperBase
    {
        /// <summary>
        /// Inherited CTOR. Calls base class' ctor.
        /// </summary>
        /// <param name="filename">Full file path of the dicom file.</param>
        public OP(string filename)
            : base(filename)
        {
            FileTypeDesc = "Ophthalmic Photography";
        }

        // Properties
        /// As this class implements the ophthalmic photography dicom 
        /// file/image data type the FileType returned is "OP" (from
        /// modality setting).
        new public string FileType
        {
            get
            {
                return "OP";
            }
        }

        /// overload property for accessing 8/16 bit image formats.
        /// \todo: handle 8/16 bit formats, do downscale to 8bit
        /// or some ToneMapping / Tone Compression?
        new public Image DicomImage
        {
            get
            {                
                return null;
            }
        }

    }
}

﻿#region information
/// 2009/01/23
/// Sebastian Lange
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;

namespace Dicom.Wrapper
{
    /// <summary>
    /// Base class for all modality-specific dicom file/image format
    /// implementations.
    /// </summary>
    class WrapperBase
    {
        /// <summary>
        /// Default CTOR.
        /// </summary>
        public WrapperBase()
        {
        }

        /// <summary>
        /// Overload CTOR, creates new Wrapper. Utility instance and opens
        /// supplied dicom file.
        /// </summary>
        /// <param name="filename">Full file path of the dicom file.</param>
        public WrapperBase(string filename)
        {
            m_dicomutil = new Dicom.Wrapper.Utility();
            m_dicomutil.SetFile(filename);
        }

        /// <summary>
        /// Static method that creates correct class instance depending on the
        /// type of dicom file/image data (i.e. OP, VL, etc.)
        /// </summary>
        /// <param name="filename">Full file path to the dicom file</param>
        /// <returns>Instance of a WrapperBase-based class</returns>
        public static WrapperBase CreateDicomWrapper(string filename)
        {
            Utility temp_util = new Utility();
            temp_util.SetFile(filename);
            string dicom_type = temp_util.GetDicomType();
            if (dicom_type == "XC")
            {
                return new VL(filename);
            }
            else if (dicom_type == "OP")
            {
                return new OP(filename);
            }
            else
            {
                // only base functionality
                return new WrapperBase(filename);
            }
        }

        /// <summary>
        /// Returns a string of the last error occured.
        /// </summary>
        /// <returns>string with the error wording.</returns>
        public string GetLastError()
        {
            return m_dicomutil.GetLastError();
        }

        // Members
        /// Instance of the utility class
        protected Utility m_dicomutil = null;        
        /// long description string of the dicom file/image data type this
        /// class implements.
        public string FileTypeDesc = "";

        // Properties
        /// Returns the first image data from the dicom file.
        public Image DicomImage
        {
            get
            {
                Image img = null;
                if (m_dicomutil.GetDicomImage(out img))
                    return img;
                else
                    return null;
            }
        }
        /// returns the string of the dicom file/image data type  type this
        /// class implements.
        public string FileType
        {
            get
            {
                return this.ToString();
            }
        }
        /// returns the name of the patient from the dicom file dataset.
        public string PatientName
        {
            get
            {
                string str = null;
                if(m_dicomutil.GetPatientName(out str))
                    return str;
                else
                    return null;
            }
        }
        /// returns the ID of the patient from the dicom file dataset.
        public string PatientID
        {
            get
            {
                string str = null;
                if (m_dicomutil.GetPatientID(out str))
                    return str;
                else
                    return null;
            }
        }
        /// returns the birth data (as string) of the patient from the dicom
        /// file dataset.
        public string PatientBirthdate
        {
            get
            {
                string str = null;
                if (m_dicomutil.GetPatientBirthdate(out str))
                    return str;
                else
                    return null;
            }
        }

    }
}

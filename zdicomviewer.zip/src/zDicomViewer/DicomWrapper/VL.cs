﻿#region information
/// 2009/01/23
/// Sebastian Lange
#endregion

using System;
using System.Collections.Generic;
using System.Text;

namespace Dicom.Wrapper
{
    /// <summary>
    /// Handles Visible Light image data.
    /// </summary>
    class VL : WrapperBase
    {
        /// <summary>
        /// Inherited CTOR. Calls base class' ctor.
        /// </summary>
        /// <param name="filename">Full file path of the dicom file.</param>
        public VL(string filename)
            : base(filename)
        {
            FileTypeDesc = "Visible Light Photographic Image IOD";
        }

        // Properties
        /// As this class implements the visible light dicom file/image data
        /// type the FileType returned is "XC" (from modality setting).
        new public string FileType
        {
            get
            {
                return "XC";
            }
        }
    }
}

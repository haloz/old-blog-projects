﻿/*! \mainpage zDicomViewer Utility
 *
 * \section intro_sec Introduction
 * Small viewer utility for image data and dataset metadata of dicom files.
 *
 * \section platform_sec Platform
 * The utility was written with Visual Studio 2008 and Microsoft Server 2008/
 * .NET 3.5 Framework under Windows XP32 and Windows Vista64. Besides of the
 * Windows Forms specific implementation parts, the wrapper classes should
 * also run on other platforms, i.e. using Mono.
 * 
 * \section dependencies_sec Dependencies
 * - .NET framework 2.0
 * - Windows Forms
 * - DICOM C# library mDCM
 */

#include "GLWindow.h"

#define WGL_CONTEXT_FORWARD_COMPATIBLE_BIT_ARB 0x0002
#define WGL_CONTEXT_MAJOR_VERSION_ARB 0x2091
#define WGL_CONTEXT_MINOR_VERSION_ARB 0x2092
#define WGL_CONTEXT_FLAGS_ARB 0x2094
typedef HGLRC (WINAPI * PFNWGLCREATECONTEXTATTRIBSARBPROC) (HDC hDC, HGLRC hShareContext, const int* attribList);

void GLWindow::CreateGL()
{
    if(m_hWnd == NULL)
    {
        throw std::exception("Window handle cannot be NULL");
    }	// If we have no window, we cannot continue

    // If any of the following steps fail, we shutdown any OpenGL elements that have been started and exit
    if (!(m_hDC=GetDC(m_hWnd)))
    {						// Retrieve the Device Context for this window
        ShutdownGL();
        throw std::exception("Could not get window Device Context");
    }

    //Create the PixelFormatDescriptor, which describes to OpenGL the pixel properties such as depth, color, and alpha channels
    PIXELFORMATDESCRIPTOR pfd;
    ZeroMemory( &pfd, sizeof(PIXELFORMATDESCRIPTOR) );
    pfd.nVersion = 1;																// The PFD version, always 1
    pfd.dwFlags = PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER;		// The properties of the PFD, in this case OpenGL support and double buffering
    pfd.iPixelType = PFD_TYPE_RGBA;													// The type of Pixels we're dealing with
    pfd.cColorBits = m_displaySettings.colorBits;									// The color depth of the window
    pfd.cAlphaBits = m_displaySettings.alphaBits;									// The alpha depth of the window
    pfd.cDepthBits = m_displaySettings.depthBits;									// The number of bits to use for the depth buffer
    pfd.nSize = sizeof(PIXELFORMATDESCRIPTOR);										// The size of this structure

    int pixelFormat;
    if (!(pixelFormat = ChoosePixelFormat(m_hDC,&pfd)))
    {
        ShutdownGL();
        throw std::exception("Could not find a suitable Pixel Format");
    }

    if(!SetPixelFormat(m_hDC,pixelFormat,&pfd))
    {			// Set the format of the Device Context
        ShutdownGL();
        throw std::exception("Could not set the Pixel Format");
    }

    // NV GL 3.0    
    HGLRC tempContext = NULL;
    if(!(tempContext = wglCreateContext(m_hDC)))
    {					// Bind the render context for drawing
        ShutdownGL();
        throw std::exception("Could not create temp. Render Context");
    }

    if(!wglMakeCurrent(m_hDC, tempContext))
    {					// Bind the render context for drawing
		wglDeleteContext(tempContext);
        ShutdownGL();
        throw std::exception("Could not make temp. Render Context current");
    }

    int attribs[] = {
		 WGL_CONTEXT_MAJOR_VERSION_ARB, 3,//we want a 3.0 context
		 WGL_CONTEXT_MINOR_VERSION_ARB, 0,//and it shall be forward compatible so that we can only use up to date functionality
		 WGL_CONTEXT_FLAGS_ARB, WGL_CONTEXT_FORWARD_COMPATIBLE_BIT_ARB,
         0 //zero indicates the end of the array
    }; 

	PFNWGLCREATECONTEXTATTRIBSARBPROC wglCreateContextAttribsARB = NULL; //pointer to the method
	wglCreateContextAttribsARB = (PFNWGLCREATECONTEXTATTRIBSARBPROC) wglGetProcAddress("wglCreateContextAttribsARB");
	if(wglCreateContextAttribsARB == NULL) //OpenGL 3.0 is not supported
    {					// Bind the render context for drawing
		wglDeleteContext(tempContext);
        ShutdownGL();
        throw std::exception("Cannot get Proc Adress for GL 3.0 CreateContextAttribs");
    }

	if (!(m_hRC=wglCreateContextAttribsARB(m_hDC,0, attribs)))
	{
		wglDeleteContext(tempContext);
        ShutdownGL();
        throw std::exception("Can't Create A GL 3.0 Rendering Context.");
	}
	wglDeleteContext(tempContext);

	if(!wglMakeCurrent(m_hDC,m_hRC))						// Try To Activate The Rendering Context
	{
        ShutdownGL();
        throw std::exception("Could not make Render Context current");
	}

}

void GLWindow::Run( void )
{
    // Setup some basic OpenGL State
    SetProjection(m_displaySettings.width, m_displaySettings.height, m_displaySettings.fieldOfView);  // Initialize our projection settings

    glClearColor(0.0f, 0.0f, 0.0f, 0.0f);	// Clear the Screen to Black
    glClearDepth(1.0f);						// Clear the Depth Buffer completely
    glDepthFunc(GL_LEQUAL);					// The method used to determine if one pixel is behind another
    glEnable(GL_DEPTH_TEST);				// Enable Z-Buffering (Depth Testing)
    glShadeModel(GL_SMOOTH);				// When shading, interpolate values between vertices

    OnStartup(); // Run the app-defined startup code. This takes place before anything is shown

    // Show the window, bring it to the front, and give it focus
    ShowWindow(m_hWnd, SW_SHOW); 
    SetForegroundWindow(m_hWnd);
    SetFocus(m_hWnd);

    // This is the actual message pump. It will loop till the user calls Exit() or the window is closed
    MSG msg;
    ZeroMemory( &msg, sizeof(msg) );
    while(msg.message != WM_QUIT) {
        // Grab the nest message in the queue
        if( PeekMessage( &msg, NULL, 0U, 0U, PM_REMOVE ) ) {
            // Send the message to our GlobalMsgProc()
            TranslateMessage( &msg );
            DispatchMessage( &msg );
        }

        if(!m_exitFlag) {
            OnFrame(); // Call the app-defined OnFrame() routine, which is where all drawing and logic should be done
        }
    }

    OnShutdown(); // Once we've exited the loop, call the app-defined shutdown code
}

void GLWindow::SetProjection( int width, int height, float fieldOfView )
{
    if(height == 0)
    { 
        height = 1;
    }		// Must have a height of at least 1 to prevent divide by 0 errors

    glViewport (0, 0, width, height);	// Tell OpenGL the size of our window 

    glMatrixMode(GL_PROJECTION);		// Notify OpenGL that we are modifying the Projection Matrix																
    glLoadIdentity();					// Set the Projection matrix to the Identiy matrix

    // The following code is a fancy bit of math that is eqivilant to calling:
    // gluPerspective( fieldOfView/2.0f, width/height , 0.1f, 255.0f )
    // We do it this way simply to avoid requiring glu.h
    GLfloat zNear = 0.1f;
    GLfloat zFar = 255.0f;
    GLfloat aspect = float(width)/float(height);
    GLfloat fH = tan( float(fieldOfView / 360.0f * 3.14159f) ) * zNear;
    GLfloat fW = fH * aspect;
    glFrustum( -fW, fW, -fH, fH, zNear, zFar );

    glMatrixMode(GL_MODELVIEW);			// Switch the matrix back to ModelView mode 																	
    glLoadIdentity();					// Set the ModelView matrix to the Identity matrix
}

void GLWindow::SwapBuffers( void )
{
    ::SwapBuffers(m_hDC);				// Swaps the contents of the backbuffer to the front, displaying any drawing we have done
}

void GLWindow::Exit( void )
{
	PostQuitMessage(0); // Post a quit message to our message pump, which will generate a WM_QUIT message
	m_exitFlag = true;
}

void GLWindow::ShutdownGL( void )
{
    if (m_hDC != NULL)
    {
        wglMakeCurrent(m_hDC, NULL);	// If we have a valid device context, unbind any render contexts from it
        if (m_hRC != NULL)
        {
            wglDeleteContext(m_hRC);	// Delete the render context if we have it
            m_hRC = NULL;
        }
        ReleaseDC(m_hWnd, m_hDC);		// Release the device context
        m_hDC = NULL;
    }
}


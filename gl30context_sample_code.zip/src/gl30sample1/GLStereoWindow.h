/*
    http://reald-corporate.com/scientific/downloads/pcsdk.htm
*/
#pragma once
#include "glwindow.h"

class GLStereoWindow :
    public GLWindow
{
public:
    GLStereoWindow(void);
    virtual ~GLStereoWindow(void);
protected:
    virtual void    CreateGL( void );
};

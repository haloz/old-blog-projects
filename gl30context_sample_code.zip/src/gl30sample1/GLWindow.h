#pragma once
#include <math.h>
#include <windows.h>
#include <string>
#include <gl/gl.h>
#include <gl/glext.h>
#include "WindowDisplaySettings.h"

class GLWindow
{
public:
    GLWindow(void);
    virtual ~GLWindow(void);

    void    SetProjection( int width, int height, float fieldOfView );				/// Set the projection matrix
    void    Create( HINSTANCE hInstance, WindowDisplaySettings& displaySettings );	/// Create a window with the specified attributes
    void    Run( void );			/// Begin the message loop
    void    Exit( void );			/// Exit the message loop 
    void    SwapBuffers( void );    /// Swap the front and back buffers

protected:    
    void                        CreateWin( void );			/// Create a window with the specified attributes
    virtual void                CreateGL( void );
    void                        ShutdownWin( void );		/// Close down the window
    void                        ShutdownGL( void );
    void                        SetDisplay( WindowDisplaySettings& displaySettings );	/// Allows us to change the resolution and color depth of the screen if we need to (ie: for fullscreen)
    void                        RevertDisplay( void );		/// Reverts the display settings back to their normal mode after changing them with SetDisplay
    virtual LRESULT CALLBACK	OnMessage( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam );		/// Called whenever a message is processed for this window
    virtual void				OnStartup( void ) PURE;		/// Called at the beginning of the Run() loop to allow user initialization code
    virtual void				OnFrame( void ) PURE;		/// Called once per loop iteration, most program drawing and logic will be done here
    virtual void				OnShutdown( void ) PURE; 	/// Called after Exit() has terminated the loop to allow user shutdown code

    HWND						m_hWnd;						/// The internal handle to our window
    HDC							m_hDC;					    /// Handle to the windows Device Context
    HGLRC						m_hRC;					    /// OpenGL Render Context for this window
    HINSTANCE					m_hInstance;				/// The HINSTANCE the window was created and registered with
    WindowDisplaySettings		m_displaySettings;		    /// Stores the display settings used to create this window

private:
    static  LRESULT CALLBACK	GlobalMsgProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam );	/// This function will forward window messages to the appropriate object's OnMessage()
    bool						m_exitFlag;				/// Indicates when we've called Exit()
};

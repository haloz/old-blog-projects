#pragma once

#include <windows.h>
#include <gl/gl.h>
#include <gl/glext.h>

class Util
{
public:
    static bool ExtensionAvailable( const char *extString );
};

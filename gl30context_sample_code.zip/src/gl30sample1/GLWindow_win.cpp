#include "GLWindow.h"

const TCHAR* GLWindowClass = TEXT("GL21_WINDOW_CLASS"); 

GLWindow::GLWindow(void)
    : m_hWnd(NULL)
    , m_exitFlag(false)
    , m_hDC(NULL)
    , m_hRC(NULL)
{
}

GLWindow::~GLWindow(void)
{
    ShutdownGL();		// Make sure OpenGL is shut down before we close the window
    ShutdownWin();		// Close the window
    RevertDisplay();	// Exit Fullscreen if nessicary
}

void GLWindow::Create(HINSTANCE hInstance, WindowDisplaySettings& displaySettings)
{
    if(!hInstance)
        throw std::exception("Cannot create window with NULL hInstance.");

    m_hInstance = hInstance;
    m_displaySettings = displaySettings;

    SetDisplay(m_displaySettings);	// Set the display into the correct mode (color depth/size/fullscreen)
    CreateWin();					// Initialize the Win32 portion of the window
    CreateGL();						// Initialize the OpenGL portion of the window
}

void GLWindow::CreateWin()
{
    // Here we will describe the windows class that we're going to be using to create our main window
    WNDCLASSEX wc;
    if(!GetClassInfoEx(m_hInstance, GLWindowClass, &wc))
    {			// See if the class is already registered
        memset(&wc,0,sizeof(WNDCLASSEX));
        wc.lpszClassName	= GLWindowClass;						// The windows class name
        wc.style			= CS_HREDRAW | CS_VREDRAW | CS_OWNDC;	// The styles for this window
        wc.lpfnWndProc		= (WNDPROC) GLWindow::GlobalMsgProc;		// The message handler for this windows class (which we will redirect later)
        wc.hInstance		= m_hInstance;							// The hInstance to create this class under
        wc.hCursor			= LoadCursor(NULL, IDC_ARROW);			// The Mouse Cursor to use with windows of this class
        wc.hIcon			= LoadIcon(NULL, IDI_WINLOGO);			// The Icon to display for windows of this class
        wc.hIconSm			= NULL;									// The Small Icon to use for windows of this class (For taskbar icons, etc) 
        wc.cbSize			= sizeof(WNDCLASSEX);					// The size of this structure

        // Attempt to register this class so we create windows with it
        if (!RegisterClassEx(&wc))
        {
            throw std::exception("Window Class could not be registered.");
        }
    }

    // Next we need to tell the window what window style to use
    // This is as simple as "when windowed we want a border, when fullscreen we don't"
    DWORD dwExStyle;
    DWORD dwStyle;

    if ( m_displaySettings.fullscreen )
    { 
        dwExStyle = WS_EX_APPWINDOW;	// This style simply ensures that our program will appear on the taskbar
        dwStyle	= WS_POPUP;				// This style indicates that the window should have no border whatsoever 
    }
    else
    {
        dwExStyle	= WS_EX_APPWINDOW | WS_EX_WINDOWEDGE;	// These two styles combined ensure the program will appear on the taskbar and that it has a nice border
        dwStyle		= WS_OVERLAPPEDWINDOW; // This indicates a combination of styles, which gives our window a title bar, caption, system menu, and minimize/maximize buttons
    }

    RECT WinRect;
    WinRect.left=(long)0;
    WinRect.top=(long)0;
    WinRect.right=(long)m_displaySettings.width;
    WinRect.bottom=(long)m_displaySettings.height;

    // This function will use the styles we set above and modify WinRect so that it as the appropriate amount of client space.
    AdjustWindowRectEx( &WinRect, dwStyle, false, dwExStyle );

    // This is the actual window creation
    m_hWnd = CreateWindowEx(  
        dwExStyle,										// The extended style that we're using, set above	 
        GLWindowClass,									// The name of the class to create this window with. This reffers to the WNDCLASSEX structure above
        m_displaySettings.caption.c_str(),				// The caption for this window
        dwStyle | WS_CLIPSIBLINGS | WS_CLIPCHILDREN,	// The window style we're using, set above, with two additions that tell windows to properly clip our window
        CW_USEDEFAULT, CW_USEDEFAULT,					// The position the windows top left corner will appear at. In this case we allow windows to decide where best to place us 
        WinRect.right,									// The Width of our window (in pixels)
        WinRect.bottom,									// The Height of our window (in pixles)
        NULL, NULL,										// These two parameters specify our parent window and the menu we want to use, neither of which we have
        m_hInstance,									// The HINSTANCE we're creating the window with
        (void*)this );									// Any user supplied data we need, in this case "this" to allow our OOP framework to pass messages properly

    // Check to see if window creation failed
    if (m_hWnd == NULL)
    {
        throw std::exception("Could not create application window");
    }
}

void GLWindow::SetDisplay( WindowDisplaySettings& displaySettings )
{
    if(displaySettings.fullscreen)
    {												// Check and see if we're in fullscreen mode, and if so signal windows to actually change the display settings
        DEVMODE dmScreenSettings;   //w32api gdi
        memset(&dmScreenSettings,0,sizeof(DEVMODE));
        dmScreenSettings.dmPelsWidth	= displaySettings.width;					// The width of the screen
        dmScreenSettings.dmPelsHeight	= displaySettings.height;					// The height of the screen 
        dmScreenSettings.dmBitsPerPel	= displaySettings.colorBits;				// How many bits per pixel to use for colors
        dmScreenSettings.dmFields		= DM_BITSPERPEL|DM_PELSWIDTH|DM_PELSHEIGHT;	// Which fields of the DEVMODE structure we will be paying attention to
        dmScreenSettings.dmSize			= sizeof(DEVMODE);							// The size of this structure

        if (ChangeDisplaySettings(&dmScreenSettings,CDS_FULLSCREEN) != DISP_CHANGE_SUCCESSFUL)
        {	// Try to change the display settings to the requested parameters
            // If it didn't work ask the user if they would prefer windowed mode, throw an error if not
            if(MessageBox(NULL, _T("The requested fullscreen mode is not supported by your video card.\n Would you like to run in windowed mode?"), _T("Run Windowed?"), MB_YESNO|MB_ICONEXCLAMATION)==IDYES)
            {
                displaySettings.fullscreen = false;
            }
            else
            {
                throw std::exception("Cannot run fullscreen with the requested settings.");
            }
        }
    }
}


//
// Message Handling
//

// Receives messages for all windows created with the Window class and forwards them to the correct Window object
LRESULT CALLBACK GLWindow::GlobalMsgProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{		
    GLWindow* parentWindow = NULL;

    // WM_NCCREATE is received immedately after the window is created, before any other messages
    if( uMsg == WM_NCCREATE )
    {
        //The lparam in this message contains the user-defined data that was supplied as the last parameter of CreateWindowEX() 
        CREATESTRUCT* create = reinterpret_cast<CREATESTRUCT*>(lParam);
        // We can extract our "this" pointer from the provided structure now
        parentWindow = reinterpret_cast<GLWindow*>(create->lpCreateParams);
        // Then we set it as a general User-Data element of the window for easy access later
        SetWindowLongPtr(hWnd, GWL_USERDATA, reinterpret_cast<LONG_PTR>(parentWindow));
    }
    else
    {
        // For any other message we need to extract the previously set user data and cast it to the correct type
        parentWindow = reinterpret_cast<GLWindow*>(GetWindowLongPtr(hWnd, GWL_USERDATA));
    }

    if( parentWindow )
    {
        // If we have a valid window now, forward the message to it
        return parentWindow->OnMessage( hWnd, uMsg, wParam, lParam );
    }
    else
    {
        //Otherwise handle it with the default behaviour
        return DefWindowProc( hWnd, uMsg, wParam, lParam );
    }
}


// The default message handler. Any inherited classes should call this in their OnMessage()
LRESULT CALLBACK GLWindow::OnMessage(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    switch( uMsg )
    {
    case WM_SIZE:
        //TODO SetProjection(LOWORD(lParam), HIWORD(lParam), m_displaySettings.fieldOfView);	// When the window resizes, update the OpenGL viewport with it
        return 0;
    case WM_SYSCOMMAND:
        // The following switch will prevent screensaver and monitor powersave messages from being processed
        // This will prevent the computer from switching to either mode while our application is running
        switch (wParam)
        {
        case SC_SCREENSAVE:					
        case SC_MONITORPOWER:				
            return 0;							
        }									
        break;
    case WM_DESTROY: // Received when the user clicks the Close button.
        Exit(); // Tell our application to exit
        return 0;
    default:
        break;
    }

    // Handle any message which wasn't previously explicitly handled
    return DefWindowProc( hWnd, uMsg, wParam, lParam ); 
} 

void GLWindow::ShutdownWin()
{
    SetWindowLongPtr(m_hWnd, GWL_USERDATA, NULL); // Clear our "this" pointer out of the windows User Data to prevent further call attempts by GlobalMsgProc() 

    if (m_hWnd)
    { // If we have a valid window handle Destroy and NULL it
        DestroyWindow(m_hWnd);
        m_hWnd=NULL;
    }
}

void GLWindow::RevertDisplay( void )
{
    ChangeDisplaySettings(NULL, 0);		// If we are in fullscreen mode, switch back to windowed mode 
}
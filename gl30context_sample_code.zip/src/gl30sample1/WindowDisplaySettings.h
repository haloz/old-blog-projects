#pragma once

#include <windows.h>
#include <tchar.h>
#include <string>
//******************
// WindowDisplaySettings
//******************

/// Contains all the information needed for creating
/// either a window with or without OpenGL. We pass 
/// it in to the Window class "Create" function.
class WindowDisplaySettings
{
public:
    WindowDisplaySettings();	/// Initializes all settings to their defaults
    WindowDisplaySettings( const WindowDisplaySettings& wds );	/// Copy constructor

    // Standard window properties
    std::wstring    				caption;		/// The caption to be displayed in the windows title bar
    int								width;			/// The width of the window in pixels
    int								height;			/// The height of the window in pixels
    bool							fullscreen;		/// Wether or not the window is fullscreen (borderless)

    // OpenGL Specific properties
    int								colorBits;		/// The color depth of the OpenGL window
    int								alphaBits;		/// The alpha depth of the OpenGL window
    int								depthBits;		/// The z-buffer depth of the OpenGL window
    float							fieldOfView;	/// The field of view (angle) of the OpenGL viewport
};
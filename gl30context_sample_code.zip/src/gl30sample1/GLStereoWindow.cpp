#include "GLStereoWindow.h"

GLStereoWindow::GLStereoWindow(void)
{
}

GLStereoWindow::~GLStereoWindow(void)
{
}

void GLStereoWindow::CreateGL()
{
    if(m_hWnd == NULL)
    {
        throw std::exception("Error: Window handle cannot be NULL");
    }	// If we have no window, we cannot continue

    // If any of the following steps fail, we shutdown any OpenGL elements that have been started and exit
    if (!(m_hDC=GetDC(m_hWnd)))
    {						// Retrieve the Device Context for this window
        ShutdownGL();
        throw std::exception("Error: Could not get window Device Context");
    }

    //Create the PixelFormatDescriptor, which describes to OpenGL the pixel properties such as depth, color, and alpha channels
    PIXELFORMATDESCRIPTOR pfd;
    ZeroMemory( &pfd, sizeof(PIXELFORMATDESCRIPTOR) );
    pfd.nVersion = 1;																// The PFD version, always 1
    pfd.dwFlags = PFD_DRAW_TO_WINDOW | PFD_SUPPORT_GDI | PFD_DOUBLEBUFFER | PFD_SUPPORT_OPENGL | PFD_STEREO;		// The properties of the PFD, in this case OpenGL support and double buffering
    pfd.iPixelType = PFD_TYPE_RGBA;													// The type of Pixels we're dealing with
    pfd.cColorBits = m_displaySettings.colorBits;									// The color depth of the window
    pfd.cAlphaBits = m_displaySettings.alphaBits;									// The alpha depth of the window
    pfd.cDepthBits = m_displaySettings.depthBits;									// The number of bits to use for the depth buffer
    pfd.nSize = sizeof(PIXELFORMATDESCRIPTOR);										// The size of this structure

    int pixelFormat;
    if (!(pixelFormat = ChoosePixelFormat(m_hDC,&pfd)))
    {
        ShutdownGL();
        throw std::exception("Error: Could not find a suitable Pixel Format");
    }

    // re-check if succeeded    
    // pCDC, iPixelFormat, pfd are declared in above code
    pixelFormat = GetPixelFormat (m_hDC);
    DescribePixelFormat (m_hDC, pixelFormat, sizeof
       (PIXELFORMATDESCRIPTOR), &pfd);
    if ((pfd.dwFlags & PFD_STEREO) == 0) // stereo mode not accepted
    {
        ShutdownGL();
        throw std::exception("Error: Stereo Mode not available!");
    }     


    if(!SetPixelFormat(m_hDC,pixelFormat,&pfd))
    {			// Set the format of the Device Context
        ShutdownGL();
        throw std::exception("Error: Could not set the Pixel Format");
    }



}
#pragma once

#ifndef _WIN32_WINNT		// Lassen Sie die Verwendung spezifischer Features von Windows XP oder sp�ter zu.                   
#define _WIN32_WINNT 0x0501	// �ndern Sie dies in den geeigneten Wert f�r andere Versionen von Windows.
#endif						

#include <stdio.h>
#include <tchar.h>
#include "WindowDisplaySettings.h"
#include "GLApp.h"

int __stdcall WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	WindowDisplaySettings wds; // We're going to leave this to it's default settings for the most part, with one or two exceptions
	wds.caption = _T("Tutorial 01 - OpenGL Window"); // Set the window caption to something appropriate for the tutorial
	
	// Ask the user if they want to run fullscreen or not, then set the fullscreen mode accordingly
	if (MessageBox(NULL, _T("Would You Like To Run In Fullscreen Mode?"), wds.caption.c_str(), MB_YESNO | MB_ICONQUESTION) == IDYES)
    { 
		wds.fullscreen = true; 
	}

	GLApp glApp;	// Define the application object

	try
    {
		glApp.Create( hInstance, wds );		// Initialize OpenGL with the previously defined window settings
	}
    catch( std::exception err )
    {			// If an error is thrown at any point during the creation we will catch it here and display it to the user
		MessageBoxA(NULL, err.what(), "OpenGL Tutorial - Error", MB_OK | MB_ICONEXCLAMATION);
		return 0;
	}

	try {
		glApp.Run();						// Enter the message pump, this will loop until we indicate that we want to exit 
	} catch ( std::exception err ) {		// If anything goes wrong while running, catch the error and display it to the user, ending the program
		MessageBoxA(NULL, err.what(), "OpenGL Tutorial - Error", MB_OK | MB_ICONEXCLAMATION);
		return 0;
	}
	
	return 1;		// And we're done!
}



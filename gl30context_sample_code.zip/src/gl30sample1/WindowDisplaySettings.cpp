#include "WindowDisplaySettings.h"
//******************
// WindowDisplaySettings
//******************

WindowDisplaySettings::WindowDisplaySettings()
    : width(800)
    , height(600)
    , fullscreen(false)
    , colorBits(32)
    , alphaBits(8)
    , depthBits(24)
    , fieldOfView(90.0f)
    , caption(_T("Untitled Window"))
{
}

WindowDisplaySettings::WindowDisplaySettings( const WindowDisplaySettings& wds )
{
    caption		= wds.caption;
    width		= wds.width;
    height		= wds.height;
    fullscreen	= wds.fullscreen;
    colorBits	= wds.colorBits;
    alphaBits	= wds.alphaBits;
    depthBits	= wds.depthBits;
    fieldOfView	= wds.fieldOfView;
}
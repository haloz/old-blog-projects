#include "GLApp.h"
#include "Util.h"

GLApp::GLApp(void)
{
}

GLApp::~GLApp(void)
{
}

void GLApp::OnFrame()
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT); // Tell OpenGL to clear the Color and Depth buffers

    //
    // Any drawing code goes here
    //

    SwapBuffers(); // Swap the front and back buffers, displaying what we have just drawn
}

LRESULT CALLBACK GLApp::OnMessage(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    //
    // In this function we can catch any windows messages that are raised and react appropriately
    //
    switch(uMsg)
    {
            case WM_KEYDOWN:						// This message is raised when a key is pressed down
                if(wParam == VK_ESCAPE)
                {			// If the key is the "Esc" key signal the program to quit
                    Exit(); 
                }
                break;
    }

    return GLWindow::OnMessage(hWnd, uMsg, wParam, lParam);	// For any message we haven't handled here, pass it on the the base class message handler
}	

void GLApp::OnStartup( void )
{
    bool bSM4 = Util::ExtensionAvailable("GL_EXT_gpu_shader4");
}

void GLApp::OnShutdown( void )
{
}
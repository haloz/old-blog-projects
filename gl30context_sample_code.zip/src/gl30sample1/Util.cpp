#include "Util.h"


bool Util::ExtensionAvailable( const char *extString )
{
	char *extList = (char*) glGetString(GL_EXTENSIONS);		// Get the string containing a space-delimited list of all the supported extensions for the current hardware
	size_t extLen = strlen(extString);						// Get the size of our requested extension string for fast comparisons
	size_t nextExtLen = 0;									// Used to store the length of each extension in the list as we process it.

	if(!extString || !extList) { return false; }			// If we don't have either a extension list or requested extension, return false 
	
	while(*extList) {										// Loop through each extention in the list till we find one that matches the requested extension
		nextExtLen = strcspn( extList, " " );				// Get the number of charecters up to the next space (which serves as a delimiter in the extension list)
		if(nextExtLen == extLen && strncmp( extList, extString, extLen ) == 0) {	// We first mach the string length, then do a char-by-char comparison
			return true;									// If the extension matches the requested one, return true
		}
		extList += nextExtLen + 1;							// If this extension did not match, move forward to the next extension string
	}

	return false;											// If we reach here we haven't found the extension in our list, so return false
}
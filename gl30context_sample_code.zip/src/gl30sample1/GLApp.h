#pragma once
#include "GlWindow.h"

class GLApp  : public GLWindow
{
public:
    GLApp(void);
    virtual ~GLApp(void);
protected:
    virtual void OnStartup( void );
    virtual void OnShutdown( void );
    virtual void OnFrame( void );
    virtual LRESULT CALLBACK OnMessage(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);

};

import com.drew.imaging.ImageMetadataReader;
import com.drew.imaging.ImageProcessingException;
import com.drew.metadata.exif.ExifReader;
import com.drew.metadata.iptc.IptcReader;
import com.sun.image.codec.jpeg.JPEGCodec;
import com.sun.image.codec.jpeg.JPEGDecodeParam;
import com.sun.image.codec.jpeg.JPEGImageDecoder;
import com.drew.metadata.*;
import com.drew.metadata.exif.ExifDirectory;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.FilenameFilter;
import java.util.*;
import java.util.regex.*;


public class FocalApp {
  public FocalApp(HashMap<String, String> parameters) {
    // list of files
    File folder = new File(parameters.get("imagepath"));
    List<File> filelist = new ArrayList<File>();
    this.getFiles(folder, filelist, parameters.get("fileext"), parameters.get("filename"));

    // key - value pairs: focallength - count
    SortedMap<Double, Integer> focalmap = new TreeMap<Double,Integer>();

    // for all found files
    for (Iterator it=filelist.iterator(); it.hasNext(); ) {
      String filename = it.next().toString();
      //System.out.println(" --- working on file: "+filename);
      performImageFile(filename, focalmap, parameters.get("camera"));
    }

    Integer totalimagecount = 0;

    TreeSet set = new TreeSet(new Comparator() {
      public int compare(Object obj, Object obj1) {
        int vcomp = ((Comparable) ((Map.Entry)
        obj1).getValue()).compareTo(((Map.Entry)
        obj).getValue());
        if (vcomp != 0) return vcomp;
        else return ((Comparable) ((Map.Entry)
        obj1).getKey()).compareTo(((Map.Entry)
        obj).getKey());

      }
    });

    set.addAll(focalmap.entrySet());
    System.out.println("focal length in mm;number of images;");
    for (Iterator i = set.iterator(); i.hasNext();) {
      Map.Entry entry = (Map.Entry) i.next();
      Double key = (Double) entry.getKey();
      String keyname;
      if(key == 0) {
        keyname = "?";
      } else {
        keyname = key.toString();
      }
      Integer numimages = (Integer) entry.getValue();
      System.out.println(keyname + ";" + numimages+";");
      totalimagecount+=numimages;
    }

    //System.out.println("total: "+totalimagecount+" images.");
  }

  private void performImageFile(String filename, SortedMap<Double, Integer> focalmap, String cameraModel) {
    File imageFile = new File(filename);
    try {
      Metadata metadata = ImageMetadataReader.readMetadata(imageFile);
      Directory exifDirectory = metadata.getDirectory(ExifDirectory.class);

      if(cameraModel != null && cameraModel.length() > 0) {
        String cameraModelInExif = exifDirectory.getString(ExifDirectory.TAG_MODEL);
        if(cameraModelInExif == null) {
          return;
        }
        cameraModelInExif = cameraModelInExif.replaceAll("(\\s|-)", "");
        cameraModel = cameraModel.replaceAll("(\\s|-)", "");
        if(cameraModelInExif.compareToIgnoreCase(cameraModel) != 0) {
          return;
        }
      }

      Double cameraFocus = 0.0;
      try {
        String cameraFocusString = exifDirectory.getString(ExifDirectory.TAG_FOCAL_LENGTH);
        if (cameraFocusString != null) {
          // value is present
          cameraFocus = Double.parseDouble(cameraFocusString);
        }
        //System.out.println("Focus lenght = " + cameraFocus);
      } catch(NumberFormatException nFE) {
        //System.out.println("Not an Integer");
      }

      Integer currentimagecount = 0;
      if(focalmap.containsKey(cameraFocus)) {
        //System.out.println("key already tgere");
        currentimagecount = focalmap.get(cameraFocus);
      }
      currentimagecount++;
      //System.out.println("putting in map: "+currentvalue);
      focalmap.put(cameraFocus, currentimagecount);
    } catch (ImageProcessingException e) {
      System.err.println("skipping file "+filename+"due to error:"+e);
    }
  }

  private void getFiles(File folder, List<File> list, String fileexts, String filenamepattern) {
    folder.setReadOnly();

    File[] files = folder.listFiles(new ImageFileFilter(fileexts, filenamepattern));
    for(int j = 0; j < files.length; j++) {
      list.add(files[j]);
    }

    File[] subfolders = folder.listFiles();
    for(int j = 0; j < subfolders.length; j++) {
      if(subfolders[j].isDirectory()) {
        getFiles(subfolders[j], list, fileexts, filenamepattern);
      }
    }
  }

  public static void main(String[] args)
  {
    //System.out.println("args length:"+args.length);
    // put command line params into hash
    if(args.length > 0 && args.length % 2 == 0) {
      HashMap<String, String> cmdlineHash = new HashMap<String, String>();

      for ( int i=0; i < args.length; i+=2 ) {
        //System.out.println("pushing argument:|" + args[i].replaceAll("(-|=|\\s)","") + "| with value:"+args[i+1]);
        cmdlineHash.put(args[i].replaceAll("(-|=|\\s)",""), args[i+1]);
      }

      if(new File(cmdlineHash.get("imagepath")).exists()) {
        new FocalApp(cmdlineHash);
      } else {
        System.err.println("given image directory not found!");
        System.out.println(GetHelp());
        System.exit(1);
      }

    } else {
      System.err.println("please give a directory containing the images!");
      System.out.println(GetHelp());
      System.exit(1);
    }
  }

  private static String GetHelp() {
    return
      ""+"\n"+
      "Build:"+"\n"+
      "    javac -Xlint:unchecked -classpath .;metadata-extractor-2.4.0-beta-1.jar FocalApp.java"+"\n"+
      "    jar cfm FocalApp.jar Manifest.txt *.class"+"\n"+
      ""+"\n"+
      "Usage:"+"\n"+
      "    java -jar FocalApp.jar [Options]"+"\n"+
      ""+"\n"+
      "Description:"+"\n"+
      "    For all images in the given directory and its subdirectories read the"+"\n"+
      "    lenses' focal length from the exif data and print a summary of how"+"\n"+
      "    often the particular focal lengths are used."+"\n"+
      ""+"\n"+
      "    Currently this program works with the following image types:"+"\n"+
      "     * JPEG"+"\n"+
      "     * CRW - Canon Raw"+"\n"+
      "     * CR2 - Canon Raw v2"+"\n"+
      "     * NEF - Nikon Raw"+"\n"+
      "     * ARW - Sony Raw"+"\n"+
      "     * TIF/TIFF"+"\n"+
      ""+"\n"+
      "Options:"+"\n"+
      "    -imagepath          path for the images to work on                          (required)"+"\n"+
      "    -camera             string with the name of the camera, the program will    (optional)"+"\n"+
      "                        only count the images containing that camera name"+"\n"+
      "    -fileext            only count images with that file extension(s)           (optional)"+"\n"+
      "    -filename           only count images matching this regular expression      (optional)"+"\n"+
      ""+"\n"+
      "Examples:"+"\n"+
      "    java -jar FocalApp.jar -imagedir \"D:\\testimages\""+"\n"+
      "    java -jar FocalApp.jar -imagedir \"D:\\testimages\" -camera \"Canon EOS 30D\" "+"\n"+
      "                           -fileext \"jpg,crw\" -filename \"^CRW(.*)\""+"\n";
  }
}

class ImageFileFilter implements FilenameFilter {

  private String m_fileexts;
  private String m_filenamepattern;


  public ImageFileFilter(String fileexts, String filenamepattern) {
    m_fileexts = fileexts;
    m_filenamepattern = filenamepattern;
    //System.out.println("ImageFileFilter CTOR, m_fileexts=|"+m_fileexts+"|, m_filenamepattern=|"+m_filenamepattern+"|");
  }

  public boolean accept( File f, String s ) {
    // file name
    if(m_filenamepattern != null) {
      Pattern namepattern = Pattern.compile(m_filenamepattern);
      if(!namepattern.matcher(s).matches()) {
        return false;
      }
    }

    // extensions
    String patternStart = "([^\\s]+(?=\\.(";
    String patternEnd = "))\\.\\2)";
    String patternExtensions = "";
    if(m_fileexts != null) {
      patternExtensions = m_fileexts.toLowerCase().replaceAll("(\\||;|,|\\s)", "|");
    } else {
      patternExtensions = "jpg|crw|cr2|nef|arw|tiff|tif";
    }
    //Pattern pattern = Pattern.compile("([^\\s]+(?=\\.(jpg|crw|cr2|nef|arw|tiff|tif))\\.\\2)", Pattern.CASE_INSENSITIVE);
    Pattern pattern = Pattern.compile(patternStart+patternExtensions+patternEnd, Pattern.CASE_INSENSITIVE);
    return pattern.matcher(s).matches();
  }
}
